from setuptools import setup

setup(
    name='ButterflyBackup',
    version='1.0.0',
    packages=[''],
    url='https://matteoguadrini.github.io/Butterfly-Backup',
    license='GPLv3',
    author='Matteo Guadrini',
    author_email='matteo.guadrini@hotmail.it',
    description='Butterfly Backup is a simple wrapper of rsync written in python'
)
